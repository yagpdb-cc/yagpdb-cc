# Economy
These files are standalone, commands that need eachtoher are combined in 1 command. Add the commands if you wish to use it. Configuration settings are done via variables at the top of the file.

As usual, there is a leading comment showing the trigger and description of the CC.

# Functionality
Bal command
Multiple commands to gain currency with
Allows you to customize it easily
many different commands
# Note: 
if PR'ing new command, please use .User.ID "coins" as dbEntry.
